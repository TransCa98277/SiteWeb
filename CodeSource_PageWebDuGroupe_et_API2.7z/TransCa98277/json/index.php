<?php
/**
 * TransCa98277 API2
 * 
 * @author : Xiaogang LI
 * @version : 1.0
 * @date : 2022-03-17
 * 
 */
header("Location: http://www.monkeymomo.xyz/TransCa98277/");
?>